
package modele;

import java.util.ArrayList;


public class Table {
    
    public ArrayList parameters;
    public int size;
    
    public Table(){
    
    }
    
}
