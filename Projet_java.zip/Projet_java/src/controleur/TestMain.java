package controleur;

import java.util.ArrayList;
import java.util.Collections;
import vue.*;
import modele.*;

public class TestMain {
    	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
                TestMain controle = new TestMain();
                
	}
        
        Connexion con ;
        Fenetre win ;
        public TestMain(){
            win = new Fenetre(this);
            
            
        }
        
        public ArrayList parametre_table(String table){
            ArrayList list = new ArrayList();
            try {
                 list = con.remplirChampsTable(table);

            } catch (Exception e) {
            }
            return list;
        }
        
        public ArrayList rechercheService(){
           ArrayList list = new ArrayList();
            try {
                 list = con.remplirChampsRequete("SELECT * FROM `service`");

            } catch (Exception e) {
            }
            return list;
        }
        
        public ArrayList rechercheChambre(){
           ArrayList list = new ArrayList();
            try {
                 list = con.remplirChampsRequete("SELECT * FROM `chambre`");

            } catch (Exception e) {
            }
            return list;
    
        }
        
        public ArrayList rechercheDocteur(){
            ArrayList list = new ArrayList();
            try{
                list=con.remplirChampsRequete("SELECT * FROM `docteur`");
            }catch (Exception e){   
            }
            
            return list;
        }
        
        public ArrayList rechercheEmploye(){
            ArrayList list = new ArrayList();
            try{
                list=con.remplirChampsRequete("SELECT * FROM `employe`");
            }catch (Exception e){   
            }
            
            return list;
        }
        
        public ArrayList rechercheInfirmier(){
            ArrayList list = new ArrayList();
            try{
                list=con.remplirChampsRequete("SELECT * FROM `infirmier`");
            }catch (Exception e){   
            }
            
            return list;
        }   
        
        public ArrayList rechercheMalade(){
            ArrayList list = new ArrayList();
            try{
                list=con.remplirChampsRequete("SELECT * FROM `malade`");
            }catch (Exception e){   
            }
            
            return list;
        }  
        
        public ArrayList rechercheHospital(){
            ArrayList list = new ArrayList();
            try{
                list=con.remplirChampsRequete("SELECT * FROM `hospitalisation`");
            }catch (Exception e){   
            }
            
            return list;
        }   
        
        public ArrayList rechercheSoin(){
            ArrayList list = new ArrayList();
            try{
                list=con.remplirChampsRequete("SELECT * FROM `soigne`");
            }catch (Exception e){   
            }
            
            return list;
        }

        public ArrayList recherche_requete(String table, String requete){
        ArrayList list = new ArrayList();
            try {
                 list = con.remplirChampsRequete("SELECT * FROM " +table+" WHERE " + requete);

            } catch (Exception e) {
            }
            return list;
            
        }
        
        public ArrayList recherche_requete_infirmier(String table, String table1 ,String requete){
        ArrayList list = new ArrayList();
            try {
                 list = con.remplirChampsRequete("SELECT `nom` , `prenom`  FROM " +table+ "," +table1+ "WHERE " + requete);

            } catch (Exception e) {
            }
            return list;
            
        }
        
        public ArrayList recherche_requete_docteur(String table, String table1 ,String requete){
        ArrayList list = new ArrayList();
            try {
                 list = con.remplirChampsRequete("SELECT `nom` , `prenom` , `specialite`  FROM " +table+ "," +table1+ "WHERE " + requete);

            } catch (Exception e) {
            }
            return list;
            
        }
        
        public ArrayList recherche_requete_malade(String table,String requete){
        ArrayList list = new ArrayList();
            try {
                 list = con.remplirChampsRequete("SELECT `nom` , `prenom`  FROM " +table+ "WHERE " + requete);

            } catch (Exception e) {
            }
            return list;
            
        }
        
        public ArrayList recherche_requete_service(String table, String table1,String table2,String requete){
        ArrayList list = new ArrayList();
            try {
                 list = con.remplirChampsRequete("SELECT `service`.nom , `service`.batiment, `employe`.nom, `employe`.prenom , `docteur`.specialite  FROM " +table+ ","+table1+ ","+table2+ "WHERE " + requete);

            } catch (Exception e) {
            }
            return list;
            
        }
        
        public void ajouter_requete_employe(String table,String requete){
            try {
                con.executeUpdate("INSERT INTO " +table+ " (`numero`, `nom`, `prenom`, `adresse`, `tel`) VALUES "+"("+requete+")");

            } catch (Exception e) {
            }
            
        }
        
        public void modifier_employe(String requete){
            try {
                con.executeUpdate(requete);

            } catch (Exception e) {
            }
            
        }
        
       
         
         
        public void connexion(){
        try {
                con =new Connexion("hopital","root","");
            } catch (Exception e) {
            }
            
        }

        public ArrayList recherche_requete() {
            throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
        }

        public String write_requete_update(int integer, String str1, String str2, String str3, String str4){

            String str = "UPDATE `employe` SET `nom`=\"" +str1+"\",`prenom`=\"" +str2+"\",`adresse`=\"" +str3+"\",`tel`=\"" +str4+"\" WHERE `numero`="+integer;
            return str;
        }
    
        public ArrayList histograme1(){
            ArrayList list = new ArrayList();
            String requete1 = "SELECT COUNT(*) as count FROM `employe`,`infirmier` WHERE `employe`.`numero`=`infirmier`.`numero`";
            String requete2 = "SELECT COUNT(*) as count FROM `employe`,`docteur` WHERE `employe`.`numero`=`docteur`.`numero`";
            String requete3 = "SELECT COUNT(*) as count FROM `employe`";

            list.add(con.nombre(requete1));
            list.add(con.nombre(requete2));
            list.add(con.nombre(requete3));
            


            return list;
        }
    
}
