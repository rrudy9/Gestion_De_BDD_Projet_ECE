package controleur;

import java.util.ArrayList;
import java.util.Collections;
import vue.*;
import modele.*;

public class TestMain {
    	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
                TestMain controle = new TestMain();
                
	}
        
        Connexion con ;
        Fenetre win ;
        public TestMain(){
            win = new Fenetre(this);
            
            
        }
        
        public ArrayList parametre_table(String table){
            ArrayList list = new ArrayList();
            try {
                 list = con.remplirChampsTable(table);

            } catch (Exception e) {
            }
            return list;
        }
        
        public ArrayList rechercheService(){
           ArrayList list = new ArrayList();
            try {
                 list = con.remplirChampsRequete("SELECT * FROM `service`");

            } catch (Exception e) {
            }
            return list;
        }
        
        public ArrayList rechercheChambre(){
           ArrayList list = new ArrayList();
            try {
                 list = con.remplirChampsRequete("SELECT * FROM `chambre`");

            } catch (Exception e) {
            }
            return list;
    
        }
        
        public ArrayList rechercheDocteur(){
            ArrayList list = new ArrayList();
            try{
                list=con.remplirChampsRequete("SELECT * FROM `docteur`");
            }catch (Exception e){   
            }
            
            return list;
        }
        
        public ArrayList rechercheEmploye(){
            ArrayList list = new ArrayList();
            try{
                list=con.remplirChampsRequete("SELECT * FROM `employe`");
            }catch (Exception e){   
            }
            
            return list;
        }
        
        public ArrayList rechercheInfirmier(){
            ArrayList list = new ArrayList();
            try{
                list=con.remplirChampsRequete("SELECT * FROM `infirmier`");
            }catch (Exception e){   
            }
            
            return list;
        }   
        
        public ArrayList rechercheMalade(){
            ArrayList list = new ArrayList();
            try{
                list=con.remplirChampsRequete("SELECT * FROM `malade`");
            }catch (Exception e){   
            }
            
            return list;
        }  
        
        public ArrayList rechercheHospital(){
            ArrayList list = new ArrayList();
            try{
                list=con.remplirChampsRequete("SELECT * FROM `hospitalisation`");
            }catch (Exception e){   
            }
            
            return list;
        }   
        
        public ArrayList rechercheSoin(){
            ArrayList list = new ArrayList();
            try{
                list=con.remplirChampsRequete("SELECT * FROM `soigne`");
            }catch (Exception e){   
            }
            
            return list;
        }

        public ArrayList recherche_requete(String table, String requete){
        ArrayList list = new ArrayList();
            try {
                 list = con.remplirChampsRequete("SELECT * FROM " +table+" WHERE " + requete);

            } catch (Exception e) {
            }
            return list;
            
        }
        
        public ArrayList recherche_requete_infirmier(String table, String table1 ,String requete){
        ArrayList list = new ArrayList();
            try {
                 list = con.remplirChampsRequete("SELECT `nom` , `prenom`  FROM " +table+ "," +table1+ "WHERE " + requete);

            } catch (Exception e) {
            }
            return list;
            
        }
        
        public ArrayList recherche_requete_docteur(String table, String table1 ,String requete){
        ArrayList list = new ArrayList();
            try {
                 list = con.remplirChampsRequete("SELECT `nom` , `prenom` , `specialite`  FROM " +table+ "," +table1+ "WHERE " + requete);

            } catch (Exception e) {
            }
            return list;
            
        }
        
        public ArrayList recherche_requete_malade(String table,String requete){
        ArrayList list = new ArrayList();
            try {
                 list = con.remplirChampsRequete("SELECT `nom` , `prenom`  FROM " +table+ "WHERE " + requete);

            } catch (Exception e) {
            }
            return list;
            
        }
        
        public ArrayList recherche_requete_service(String table, String table1,String table2,String requete){
        ArrayList list = new ArrayList();
            try {
                 list = con.remplirChampsRequete("SELECT `service`.nom , `service`.batiment, `employe`.nom, `employe`.prenom , `docteur`.specialite  FROM " +table+ ","+table1+ ","+table2+ "WHERE " + requete);

            } catch (Exception e) {
            }
            return list;
            
        }
        
        public void ajouter_requete_employe(String table,String requete){
            try {
                con.executeUpdate("INSERT INTO " +table+ " (`numero`, `nom`, `prenom`, `adresse`, `tel`) VALUES "+"("+requete+")");

            } catch (Exception e) {
            }
            
        }
        
        public void ajouter_requete_service(String table,String requete){
            try {
                con.executeUpdate("INSERT INTO " +table+ " (`code`, `nom`, `batiment`, `directeur`) VALUES "+"("+requete+")");
                
               
            } catch (Exception e) {
            }
            
        }
        
        public void ajouter_requete_chambre(String table,String requete){
            try {
                con.executeUpdate("INSERT INTO " +table+ " (`code_service`, `no_chambre`, `surveillant`, `nb_lits`) VALUES "+"("+requete+")");
                
               
            } catch (Exception e) {
            }
            
        }
        
        public void ajouter_requete_docteur(String table,String requete){
            try {
                con.executeUpdate("INSERT INTO " +table+ " (`numero`, `specialite`) VALUES "+"("+requete+")");
                
               
            } catch (Exception e) {
            }
            
        }
        
        public void ajouter_requete_infirmier(String table,String requete){
            try {
                con.executeUpdate("INSERT INTO " +table+ " (`numero`, `code_service`,`rotation`,`salaire`) VALUES "+"("+requete+")");
                
               
            } catch (Exception e) {
            }
            
        }
        
        
        
          
        public void ajouter_requete_malade(String table,String requete){
            try {
                con.executeUpdate("INSERT INTO " +table+ " (`numero`, `nom`,`prenom`,`adresse`,`tel`,`mutuelle`) VALUES "+"("+requete+")");
                
               
            } catch (Exception e) {
            }
            
        }
        
        
        
        
        public void ajouter_requete_hopital(String table,String requete){
            try {
                con.executeUpdate("INSERT INTO " +table+ " (`no_malade`, `code_service`,`no_chambre`,`lit`) VALUES "+"("+requete+")");
                
               
            } catch (Exception e) {
            }
            
        }
        
         public void ajouter_requete_soigne(String table,String requete){
            try {
                con.executeUpdate("INSERT INTO " +table+ " (`no_docteur`, `no_malade`) VALUES "+"("+requete+")");
                
               
            } catch (Exception e) {
            }
            
        }
         
         
        public void supprimer(String requete){
            try {
                con.executeUpdate(requete);
                
               
            } catch (Exception e) {
            }
            
        }
    
        
        
        public String write_requete_delete_service(String str1){

            String str = "DELETE FROM `employe` WHERE `no_chambre`="+str1;
            return str;
        }
         
        
        public String write_requete_delete_chambre(int integer1){

            String str = "DELETE FROM `chambre` WHERE `code`="+integer1;
            return str;
        }
         
        
        public String write_requete_delete_employe(int integer1){

            String str = "DELETE FROM `employe` WHERE `numero`="+integer1;
            return str;
        }
         
        
        public String write_requete_delete_docteur(int integer1){

            String str = "DELETE FROM `docteur` WHERE `numero`="+integer1;
            return str;
        }
        
        
        public String write_requete_delete_infirmier(int integer1){

            String str = "DELETE FROM `infirmier` WHERE `numero`="+integer1;
            return str;
        }
        
        
        public String write_requete_delete_malade(int integer1){

            String str = "DELETE FROM `malade` WHERE `numero`="+integer1;
            return str;
        }
        
        
        public String write_requete_delete_hopital(int integer1){

            String str = "DELETE FROM `hospitalisation` WHERE `no_malade`="+integer1;
            return str;
        }
        
        public void modifier(String requete){
            try {
                con.executeUpdate(requete);

            } catch (Exception e) {
            }
            
        }
        
        public String write_requete_update_employe(int integer, String str1, String str2, String str3, String str4){

            String str = "UPDATE `employe` SET `nom`=\"" +str1+"\",`prenom`=\"" +str2+"\",`adresse`=\"" +str3+"\",`tel`=\"" +str4+"\" WHERE `numero`="+integer;
            return str;
        }
    
        
        public String write_requete_update_service(String str1, String str2, String str3, int integer1){

            String str = "UPDATE `service` SET `code`=\"" +str1+"\",`nom`=\"" +str2+"\",`batiment`=\"" +str3+"\",`directeur`=\"" +integer1+"\" WHERE `code`="+str1;
            return str;
        }
        
        public String write_requete_update_chambre(String str1, int integer1, int integer2, int integer3){

            String str = "UPDATE `chambre` SET `code_service`=\"" +str1+"\",`no_chambre`=\"" +integer1+"\",`surveillant`=\"" +integer2+"\",`nb_lits`=\"" +integer3+"\" WHERE `code_service`="+str1;
            return str;
        }
    
        public String write_requete_update_docteur(int integer1, String str1){

            String str = "UPDATE `docteur` SET `numero`=\"" +integer1+"\",`specialite`=\"" +str1+"\" WHERE `numero`="+integer1;
            return str;
        }
        
        
        
        public String write_requete_update_infirmier(int integer1, String str1, String str2 ,int integer2 ){

            String str = "UPDATE `infirmier` SET `numero`=\"" +integer1+"\",`code_service`=\"" +str1+"\", `rotation`=\""+str1+"\", `salaire`=\""+integer2+"\" WHERE `numero`="+integer1;
            return str;
        }
        
        
        public String write_requete_update_malade(int integer1, String str1, String str2,String str3,String str4, String str5){

            String str = "UPDATE `malade` SET `numero`=\"" +integer1+"\",`nom`=\"" +str1+"\", `prenom`=\""+str2+"\", `adresse`=\""+str3+"\", `tel`=\""+str4+"\", `mutuelle`=\""+str3+"\" WHERE `numero`="+integer1;
            return str;
        }
        
        
      
        public String write_requete_update_hopital(int integer1, String str1,int integer2, int integer3){

            String str = "UPDATE `hospitalisation` SET `no_malade`=\"" +integer1+"\",`code_service`=\"" +str1+"\", `no_chambre`=\""+integer2+"\", `lit`=\""+integer3+"\"  WHERE `no_malade`="+integer1;
            return str;
        }
        
        
      
         public String write_requete_update_soin(int integer1,int integer2){

            String str = "UPDATE `soigne` SET `no_docteur`=\"" +integer1+"\", `no_malade`=\""+integer2+"\", WHERE `no_docteur`="+integer1;
            return str;
        }
        

        public void connexion(){
        try {
                con =new Connexion("hopital","root","");
            } catch (Exception e) {
            }
            
        }

        public ArrayList recherche_requete() {
            throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
        }

      
        public ArrayList histograme1(){
            ArrayList list = new ArrayList();
            String requete1 = "SELECT COUNT(*) as count FROM `employe`,`infirmier` WHERE `employe`.`numero`=`infirmier`.`numero`";
            String requete2 = "SELECT COUNT(*) as count FROM `employe`,`docteur` WHERE `employe`.`numero`=`docteur`.`numero`";
            String requete3 = "SELECT COUNT(*) as count FROM `employe`";

            list.add(con.nombre(requete1));
            list.add(con.nombre(requete2));
            list.add(con.nombre(requete3));
            


            return list;
        }
        
        
        
        
        
        
        
        
        
        
        
    
}
