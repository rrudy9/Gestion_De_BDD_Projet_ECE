
package vue;

import controleur.*;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTabbedPane;
import javax.swing.JToolBar;
import javax.swing.ScrollPaneLayout;
import org.jfree.chart.ChartFactory;
import org.jfree.chart.ChartPanel;
import org.jfree.chart.JFreeChart;
import org.jfree.data.general.DefaultPieDataset;

public class Fenetre extends JFrame implements ActionListener{

	private JPanel pan;
	private TestMain controle;
	private JToolBar toolbar ;
        
        
         
     
	private JTabbedPane  tab_onglet ;
	private panel_champs tab_onglet2 ;
	private panel_champs tab_onglet3 ;

        private JScrollPane scroll;
	
        private JScrollPane scroll1;

	private JButton bouton1;
	private JButton bouton2;
	private JButton ok_bouton;
	private JButton ajouter_bouton;
        private JButton supprimer_bouton;
        private JButton modifier_bouton;
        private JButton maj;
        
        
       
	
	private JPanel pan1 ;
	private JPanel pan2 ;
	private JPanel pan3 ;
	
     
	private JPanel result ;
	private JPanel ok ;
	private JPanel ajouter ;

        public boolean connecte;

	public Fenetre(TestMain cntrl) {
		
            controle = cntrl;
            connecte = false;
            this.setSize(900, 600);
            pan = new JPanel(); // instancier le panneau
            toolbar = new JToolBar();
            tab_onglet = new JTabbedPane();
            tab_onglet2 = new panel_champs();
            tab_onglet3 = new panel_champs();
		
            result = new JPanel();
            ok = new JPanel();
            ajouter = new JPanel();
		
                
            pan1 = new JPanel(); // instancier le panneau
            pan2 = new JPanel(); // instancier le panneau
            pan3 = new JPanel(); // instancier le panneau
		

            ok_bouton= new JButton("OK");
            ajouter_bouton= new JButton("Ajouter");
            supprimer_bouton= new JButton("Supprimer");
            modifier_bouton= new JButton("Modifier");
            maj= new JButton("MaJ");
           
            
            ok.add(ok_bouton);
            ajouter.add(ajouter_bouton);
            ajouter.add(supprimer_bouton);
            ajouter.add(modifier_bouton);
            
            ok_bouton.addActionListener(this);
            ajouter_bouton.addActionListener(this);
            modifier_bouton.addActionListener(this);
            supprimer_bouton.addActionListener(this);
            maj.addActionListener(this);
                
            result.setBackground(Color.WHITE);
            pan3.setBackground(Color.gray);
		
                

            scroll = new JScrollPane(result,JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED,JScrollPane.HORIZONTAL_SCROLLBAR_NEVER);

            scroll.setLayout(new ScrollPaneLayout());
            scroll.setSize(new Dimension(800, 200));
                
            
            pan1.setLayout(new BorderLayout());
            pan1.add(tab_onglet2,BorderLayout.NORTH);
            pan1.add(scroll,BorderLayout.CENTER);
            pan1.add(ok,BorderLayout.SOUTH);
		
            pan2.setLayout(new BorderLayout());
            pan2.add(tab_onglet3,BorderLayout.NORTH);
            pan2.add(ajouter,BorderLayout.SOUTH);
            
            pan3.setLayout(new BorderLayout());
            pan3.add(maj,BorderLayout.SOUTH);

		
            tab_onglet.add("Recherche", pan1);
            tab_onglet.add("Ajouter", pan2);
            tab_onglet.add("Monitoring", pan3);
		
		
		
		
            bouton1= new JButton("Connection locale");
            bouton2= new JButton("Connection ECE");
		
            bouton1.addActionListener(this);
           
            toolbar.add(bouton1);
            toolbar.add(bouton2);

	
		
		
            getContentPane().setLayout(new BorderLayout());
            getContentPane().add(toolbar,BorderLayout.NORTH);
            getContentPane().add(tab_onglet,BorderLayout.CENTER); //
            this.setVisible(true);
		
	}
	
	@Override
	public void actionPerformed(ActionEvent e) {
            
            // TODO Auto-generated method stu
            if(e.getSource() == bouton1) {
                
                controle.connexion();
                connecte = true;
                affiche_chart();

                }
                
            if(connecte == true){
		if(e.getSource() == ok_bouton) {
                    
                        if(tab_onglet2.getSelectedIndex() ==0){
                            String requete = "";
                            int premier = 1;

                            String st1 = tab_onglet2.tab_jtf_service.get(0).getText().trim();
                            String st2= tab_onglet2.tab_jtf_service.get(1).getText().trim();
                            String st3= tab_onglet2.tab_jtf_service.get(2).getText().trim();
                            int integer =0;
                            if(tab_onglet2.tab_jtf_service.get(3).getText().length() != 0){
                                integer= Integer.parseInt(tab_onglet2.tab_jtf_service.get(3).getText().trim());
                            }
                            if(st1.compareTo("") == 0 && st2.compareTo("") == 0 && st3.compareTo("") == 0 && integer== 0){
                                result.setLayout(new GridLayout(0,4));
                                result.removeAll();
                                ArrayList list =controle.rechercheService(); 
                                ArrayList title = controle.parametre_table("service");
                                String str_temp = "";
                                for(int i = 0;i<list.size();i++){
                                    this.affiche_result(list.get(i).toString().toCharArray());
                                }
                            }
                            else {
                                result.setLayout(new GridLayout(0,5));
                                if (st1.compareTo("") != 0 ){
                                    requete +="`service`.code=\""+st1+"\"";
                                    premier = 0;
                                }
                                if (st2.compareTo("") != 0 ){
                                    if (premier ==0){
                                        requete += " AND ";
                                    }
                                    requete +="`nom`=\""+st2+"\"";
                                    premier = 0;

                                }
                                if (st3.compareTo("") != 0 ){
                                    if (premier ==0){
                                        requete += " AND ";
                                    }
                                    requete +="`batiment`=\""+st3+"\"";
                                    premier = 0;

                                }
                                if (integer != 0 ){
                                    if (premier ==0){
                                        requete += " AND ";
                                    }
                                    requete +="`directeur`=\""+integer+"\"";
                                    premier = 0;

                                }
                                
                                if (premier==0){
                                    requete+="AND";
                                    requete+="`service`.`directeur`"+"="+"`docteur`.`numero`" ;
                                }
                                
                                if (premier==0){
                                    requete+="AND";
                                    requete+="`docteur`.`numero`"+"="+"`employe`.`numero`";
                                }
                                

                                ArrayList list =controle.recherche_requete_service("`service`","`docteur`","`employe`",requete); 
                                ArrayList title = controle.parametre_table("");
                                result.removeAll();
                                for(int i = 0;i<list.size();i++){
                                    affiche_result(list.get(i).toString().toCharArray());
                                }



                            }
                            System.out.println(controle.rechercheService());
                            }
                    
                    
                        if(tab_onglet2.getSelectedIndex() ==1){
                            String requete = "";
                            int premier = 1;

                            String st1 = tab_onglet2.tab_jtf_chambre.get(0).getText().trim();

                            int integer1 =0;
                            if(tab_onglet2.tab_jtf_chambre.get(1).getText().length() != 0){
                                integer1= Integer.parseInt(tab_onglet2.tab_jtf_chambre.get(1).getText().trim());
                            }
                            int integer2 =0;
                            if(tab_onglet2.tab_jtf_chambre.get(2).getText().length() != 0){
                                integer2= Integer.parseInt(tab_onglet2.tab_jtf_chambre.get(2).getText().trim());
                            }                        
                            int integer3 =0;
                            if(tab_onglet2.tab_jtf_chambre.get(3).getText().length() != 0){
                                integer3= Integer.parseInt(tab_onglet2.tab_jtf_chambre.get(3).getText().trim());
                            }
                            if(st1.compareTo("") == 0 && integer1== 0 && integer2== 0 && integer3== 0){


                                ArrayList list =controle.rechercheChambre(); 
                                ArrayList title = controle.parametre_table("");
                                result.setLayout(new GridLayout(0,4));
                                result.removeAll();
                                for(int i = 0;i<list.size();i++){
                                    affiche_result(list.get(i).toString().toCharArray());}

                                System.out.println(controle.rechercheChambre());

                            }

                            else{
                                if (st1.compareTo("") != 0 ){
                                    requete +="`code_service`=\""+st1+"\"";
                                    premier = 0;
                                }
                                if (integer1 != 0 ){
                                    if (premier ==0){
                                        requete += " AND ";
                                    }

                                    requete +="`no_chambre`=\""+integer1+"\"";
                                    premier = 0;

                                }
                                if (integer2 != 0 ){
                                    if (premier ==0){
                                        requete += " AND ";
                                    }
                                    requete +="`surveillant`=\""+integer2+"\"";
                                    premier = 0;

                                }
                                if (integer3 != 0 ){
                                    if (premier ==0){
                                        requete += " AND ";
                                    }
                                    requete +="`nb_lits`=\""+integer3+"\"";
                                    premier = 0;

                                }

                                ArrayList list =controle.recherche_requete("`chambre`",requete); 
                                ArrayList title = controle.parametre_table("");
                                result.setLayout(new GridLayout(0,4));
                                result.removeAll();
                                for(int i = 0;i<list.size();i++){
                                    affiche_result(list.get(i).toString().toCharArray());
                                }
                            }  
                        }
                          
                        
                        if(tab_onglet2.getSelectedIndex() ==2){
                            String requete = "";
                            int premier = 1;

                            int integer =0;
                            if(tab_onglet2.tab_jtf_employe.get(0).getText().length() != 0){
                                integer= Integer.parseInt(tab_onglet2.tab_jtf_employe.get(0).getText().trim());
                            }
                            String st1= tab_onglet2.tab_jtf_employe.get(1).getText().trim();
                            String st2= tab_onglet2.tab_jtf_employe.get(2).getText().trim();
                            String st3= tab_onglet2.tab_jtf_employe.get(3).getText().trim();
                            String st4= tab_onglet2.tab_jtf_employe.get(4).getText().trim();

                            if(integer == 0 && st1.compareTo("") == 0 && st2.compareTo("") == 0 && st3.compareTo("") == 0 && st4.compareTo("")==0 ){
                                result.setLayout(new GridLayout(0,6));
                                result.removeAll();
                                ArrayList list =controle.rechercheEmploye(); 
                                ArrayList title = controle.parametre_table("employe");
                                String str_temp = "";
                                for(int i = 0;i<list.size();i++){
                                    this.affiche_result(list.get(i).toString().toCharArray());
                                }
                            }
                            else {
                                 result.setLayout(new GridLayout(0,6));

                                if (integer != 0 ){
                                    requete +="`numero`=\""+integer+"\"";
                                    premier = 0;
                                }
                                if (st1.compareTo("") != 0 ){
                                    if (premier ==0){
                                        requete += " AND ";
                                    }
                                    requete +="`nom`=\""+st1+"\"";
                                    premier = 0;

                                }
                                if (st2.compareTo("") != 0 ){
                                    if (premier ==0){
                                        requete += " AND ";
                                    }
                                    requete +="`prenom`=\""+st2+"\"";
                                    premier = 0;

                                }
                                if (st3.compareTo("") != 0 ){
                                    if (premier ==0){
                                        requete += " AND ";
                                    }
                                    requete +="`adresse`=\""+st3+"\"";
                                    premier = 0;

                                }
                                if (st4.compareTo("") != 0 ){
                                    if (premier ==0){
                                        requete += " AND ";
                                    }
                                    requete +="`tel`=\""+st4+"\"";
                                    premier = 0;

                                }

                                ArrayList list =controle.recherche_requete("`employe`",requete); 
                                ArrayList title = controle.parametre_table("");
                                result.removeAll();
                                for(int i = 0;i<list.size();i++){
                                    affiche_result(list.get(i).toString().toCharArray());
                                }

                            }
                           
                        }
       
                        if(tab_onglet2.getSelectedIndex() ==3){
                            String requete = "";
                            int premier = 1;

                            int integer1 =0;
                            if(tab_onglet2.tab_jtf_docteur.get(0).getText().length() != 0){
                                integer1= Integer.parseInt(tab_onglet2.tab_jtf_docteur.get(0).getText().trim());
                            }
                            
                            String st1 = tab_onglet2.tab_jtf_docteur.get(1).getText().trim();
                          
                            if( integer1== 0 && st1.compareTo("") == 0 ){


                                ArrayList list =controle.rechercheDocteur(); 
                                ArrayList title = controle.parametre_table("");
                                result.setLayout(new GridLayout(0,4));
                                result.removeAll();
                                for(int i = 0;i<list.size();i++){
                                    affiche_result(list.get(i).toString().toCharArray());}

                                System.out.println(controle.rechercheDocteur());

                            }

                            else{
                                if (integer1 != 0 ){
                                    requete +="`docteur`.numero=\""+integer1+"\"";
                                    premier = 0;
                                }
                                if (st1.compareTo("") != 0 ){
                                    if (premier ==0){
                                        requete += " AND ";
                                    }

                                    requete +="`specialite`=\""+st1+"\"";
                                    premier = 0;
                                }
                                
                                if (premier==0){
                                    requete+="AND";
                                    requete+="`docteur`.numero"+"="+"`employe`.numero";
                                }
                  
                                ArrayList list =controle.recherche_requete_docteur("`docteur`", "`employe`", requete); 
                                ArrayList title = controle.parametre_table("");
                                result.setLayout(new GridLayout(0,4));
                                result.removeAll();
                                for(int i = 0;i<list.size();i++){
                                    affiche_result(list.get(i).toString().toCharArray());
                                }
                            }  
                        }
                        
                        if(tab_onglet2.getSelectedIndex() ==4){
                            String requete = "";
                            int premier = 1;

                            int integer1 =0;
                            if(tab_onglet2.tab_jtf_infirmier.get(0).getText().length() != 0){
                                integer1= Integer.parseInt(tab_onglet2.tab_jtf_infirmier.get(0).getText().trim());
                            }
                            
                            
                            String st1 = tab_onglet2.tab_jtf_infirmier.get(1).getText().trim();
                            String st2 = tab_onglet2.tab_jtf_infirmier.get(2).getText().trim();
                          
                            int integer2 =0;
                            if(tab_onglet2.tab_jtf_infirmier.get(3).getText().length() != 0){
                                integer2= Integer.parseInt(tab_onglet2.tab_jtf_infirmier.get(3).getText().trim());
                            }
                            if( integer1== 0 && st1.compareTo("") == 0 && st2.compareTo("") == 0 && integer2 == 0 ){


                                ArrayList list =controle.rechercheInfirmier(); 
                                ArrayList title = controle.parametre_table("");
                                result.setLayout(new GridLayout(0,4));
                                result.removeAll();
                                for(int i = 0;i<list.size();i++){
                                    affiche_result(list.get(i).toString().toCharArray());}

                                System.out.println(controle.rechercheInfirmier());

                            }

                            else{
                                if (integer1 != 0 ){
                                    requete +="`infirmier`.numero=\""+integer1+"\"";
                                    premier = 0;
                                }
                                if (st1.compareTo("") != 0 ){
                                    if (premier ==0){
                                        requete += " AND ";
                                    }

                                    requete +="`code_service`=\""+st1+"\"";
                                    premier = 0;

                                }       
                                
                                if (st2.compareTo("") != 0 ){
                                    if (premier ==0){
                                        requete += " AND ";
                                    }

                                    requete +="`rotation`=\""+st2+"\"";
                                    premier = 0;

                                }       
                                if (integer2 != 0 ){
                                    if (premier ==0){
                                        requete += " AND ";
                                    }

                                    requete +="`salaire`=\""+integer2+"\"";
                                    premier = 0;

                                }
                             
                                if (premier==0){
                                    requete+="AND";
                                    requete+="`infirmier`.numero"+ "="+ "`employe`.numero";
                                }
                              // requete += "AND" + "`infirmier`.numero=" +integer1+"="+ "`employe`.numero="+tab_onglet2.tab_jtf_employe.get(0).getText();
                               
                                
                                
                                
                                ArrayList list =controle.recherche_requete_infirmier("`infirmier`","`employe`",requete); 
                                ArrayList title = controle.parametre_table("");
                                result.setLayout(new GridLayout(0,4));
                                result.removeAll();
                                for(int i = 0;i<list.size();i++){
                                    affiche_result(list.get(i).toString().toCharArray());
                                }
                            }  
                        }
                        
                        if(tab_onglet2.getSelectedIndex() ==5){
                            String requete = "";
                            int premier = 1;

                            int integer1 =0;
                            if(tab_onglet2.tab_jtf_malade.get(0).getText().length() != 0){
                                integer1= Integer.parseInt(tab_onglet2.tab_jtf_malade.get(0).getText().trim());
                            }
                            
                            String st1 = tab_onglet2.tab_jtf_malade.get(1).getText().trim();
                            String st2 = tab_onglet2.tab_jtf_malade.get(2).getText().trim();
                            String st3 = tab_onglet2.tab_jtf_malade.get(3).getText().trim();
                            String st4 = tab_onglet2.tab_jtf_malade.get(4).getText().trim();
                            String st5 = tab_onglet2.tab_jtf_malade.get(5).getText().trim();
                          
                          
                            if( integer1== 0 && st1.compareTo("") == 0 && st2.compareTo("") == 0 && st3.compareTo("") == 0 && st4.compareTo("") ==0 && st5.compareTo("") ==0  ){


                                ArrayList list =controle.rechercheMalade(); 
                                ArrayList title = controle.parametre_table("");
                                result.setLayout(new GridLayout(0,4));
                                result.removeAll();
                                for(int i = 0;i<list.size();i++){
                                    affiche_result(list.get(i).toString().toCharArray());}

                                System.out.println(controle.rechercheMalade());

                            }

                            else{
                                if (integer1 != 0 ){
                                    requete +="`numero`=\""+integer1+"\"";
                                    premier = 0;
                                }
                                if (st1.compareTo("") != 0 ){
                                    if (premier ==0){
                                        requete += " AND ";
                                    }

                                    requete +="`nom`=\""+st1+"\"";
                                    premier = 0;

                                }       
                                
                                if (st2.compareTo("") != 0 ){
                                    if (premier ==0){
                                        requete += " AND ";
                                    }

                                    requete +="`prenom`=\""+st2+"\"";
                                    premier = 0;

                                }       
                                if (st3.compareTo("") != 0 ){
                                    if (premier ==0){
                                        requete += " AND ";
                                    }

                                    requete +="`adresse`=\""+st3+"\"";
                                    premier = 0;

                                }  
                                
                                if (st4.compareTo("") != 0 ){
                                    if (premier ==0){
                                        requete += " AND ";
                                    }

                                    requete +="`tel`=\""+st4+"\"";
                                    premier = 0;

                                }
                                
                                if (st5.compareTo("") != 0 ){
                                    if (premier ==0){
                                        requete += " AND ";
                                    }

                                    requete +="`mutuelle`=\""+st5+"\"";
                                    premier = 0;

                                }
                         
                                ArrayList list =controle.recherche_requete_malade("`malade`",requete); 
                                ArrayList title = controle.parametre_table("");
                                result.setLayout(new GridLayout(0,4));
                                result.removeAll();
                                for(int i = 0;i<list.size();i++){
                                    affiche_result(list.get(i).toString().toCharArray());
                                }
                            }  
                        }
                        
                        if(tab_onglet2.getSelectedIndex() ==6){
                            String requete = "";
                            int premier = 1;

                            int integer1 =0;
                            if(tab_onglet2.tab_jtf_hospital.get(0).getText().length() != 0){
                                integer1= Integer.parseInt(tab_onglet2.tab_jtf_hospital.get(0).getText().trim());
                            }
                            
                            String st1 = tab_onglet2.tab_jtf_hospital.get(1).getText().trim();
                           
                            int integer2 =0;
                            if(tab_onglet2.tab_jtf_hospital.get(2).getText().length() != 0){
                                integer2= Integer.parseInt(tab_onglet2.tab_jtf_hospital.get(2).getText().trim());
                            } 
                            
                            int integer3 =0;
                            if(tab_onglet2.tab_jtf_hospital.get(3).getText().length() != 0){
                                integer3= Integer.parseInt(tab_onglet2.tab_jtf_hospital.get(3).getText().trim());
                            }
                          
                        
                            if( integer1== 0 && st1.compareTo("") == 0 && integer2 == 0 && integer3 == 0){


                                ArrayList list =controle.rechercheHospital(); 
                                ArrayList title = controle.parametre_table("");
                                result.setLayout(new GridLayout(0,4));
                                result.removeAll();
                                for(int i = 0;i<list.size();i++){
                                    affiche_result(list.get(i).toString().toCharArray());}

                                System.out.println(controle.rechercheHospital());

                            }

                            else{
                                if (integer1 != 0 ){
                                    requete +="`no_malade`=\""+integer1+"\"";
                                    premier = 0;
                                }
                                if (st1.compareTo("") != 0 ){
                                    if (premier ==0){
                                        requete += " AND ";
                                    }

                                    requete +="`code_service`=\""+st1+"\"";
                                    premier = 0;

                                }       
                                
                                if (integer2 != 0 ){
                                    if (premier ==0){
                                        requete += " AND ";
                                    }

                                    requete +="`no_chambre`=\""+integer2+"\"";
                                    premier = 0;

                                }       
                                if (integer3 != 0 ){
                                    if (premier ==0){
                                        requete += " AND ";
                                    }

                                    requete +="`lit`=\""+integer3+"\"";
                                    premier = 0;

                                }  
                                
                            
                                ArrayList list =controle.recherche_requete("`hospitalisation`",requete); 
                                ArrayList title = controle.parametre_table("");
                                result.setLayout(new GridLayout(0,4));
                                result.removeAll();
                                for(int i = 0;i<list.size();i++){
                                    affiche_result(list.get(i).toString().toCharArray());
                                }
                            }  
                        }
                        
                        if(tab_onglet2.getSelectedIndex() ==7){
                           
      
                            
                            String requete = "";
                            int premier = 1;

                            int integer1 =0;
                            if(tab_onglet2.tab_jtf_soin.get(0).getText().length() != 0){
                                integer1= Integer.parseInt(tab_onglet2.tab_jtf_soin.get(0).getText().trim());
                            }
                            
                            int integer2 =0;
                            if(tab_onglet2.tab_jtf_soin.get(1).getText().length() != 0){
                                integer2= Integer.parseInt(tab_onglet2.tab_jtf_soin.get(1).getText().trim());
                            } 
                            
                            if( integer1== 0 && integer2 == 0 ){


                                ArrayList list =controle.rechercheSoin(); 
                                ArrayList title = controle.parametre_table("");
                                result.setLayout(new GridLayout(0,4));
                                result.removeAll();
                                for(int i = 0;i<list.size();i++){
                                    affiche_result(list.get(i).toString().toCharArray());}

                                System.out.println(controle.rechercheSoin());
                                    
                            }

                            else{
                                if (integer1 != 0 ){
                                    requete +="`no_docteur`=\""+integer1+"\"";
                                    premier = 0;
                                }
                    
                                if (integer2 != 0 ){
                                    if (premier ==0){
                                        requete += " AND ";
                                    }

                                    requete +="`no_malade`=\""+integer2+"\"";
                                    premier = 0;

                                }       
               
                                ArrayList list =controle.recherche_requete("`soigne`",requete); 
                                ArrayList title = controle.parametre_table("");
                                result.setLayout(new GridLayout(0,4));
                                result.removeAll();
                                for(int i = 0;i<list.size();i++){
                                    affiche_result(list.get(i).toString().toCharArray());
                                }
                            }  
                        }
                        
                   
                }
                    
                        
                        
                        
                        
                        
                        


                    
                    
                      
                                                                                                
                        
                    
                if (e.getSource()== ajouter_bouton){
                    
                    if(tab_onglet3.getSelectedIndex() ==0){
                        
                        String requete = "";
                        int premier = 1;

                        String st1 = tab_onglet3.tab_jtf_service.get(0).getText().trim();
                        String st2= tab_onglet3.tab_jtf_service.get(1).getText().trim();
                        String st3= tab_onglet3.tab_jtf_service.get(2).getText().trim();
                        int integer =0;
                        if(tab_onglet3.tab_jtf_service.get(3).getText().length() != 0){
                            integer= Integer.parseInt(tab_onglet3.tab_jtf_service.get(3).getText().trim());
                        }
                        if(st1.compareTo("") == 0 && st2.compareTo("") == 0 && st3.compareTo("") == 0 && integer== 0){
                           
                            JOptionPane jop2 = new JOptionPane();
                            jop2.showMessageDialog(null, "Attention", "Veuillez remplir les champs", JOptionPane.WARNING_MESSAGE);
                            }
                            else {
                                
                                if (st1.compareTo("") != 0 ){
                                    requete +="\""+st1+"\"";
                                    premier = 0;
                                }
                                if (st2.compareTo("") != 0 ){
                                    if (premier ==0){
                                        requete += ",";
                                    }
                                    requete +="\""+st2+"\"";
                                    premier = 0;

                                }
                                if (st3.compareTo("") != 0 ){
                                    if (premier ==0){
                                        requete += ",";
                                    }
                                    requete +="\""+st3+"\"";
                                    premier = 0;

                                }
                                if (integer != 0 ){
                                    if (premier ==0){
                                        requete += ",";
                                    }
                                    requete +="\""+integer+"\"";
                                    premier = 0;

                                }
                  
                                controle.ajouter_requete_service("`service`",requete); 
                                JOptionPane jop2 = new JOptionPane();
                                 jop2.showMessageDialog(null, "okay", "yoo", JOptionPane.WARNING_MESSAGE);
                              



                            }
                           
                            }
                    
                    
                    
                        if(tab_onglet3.getSelectedIndex() ==1){
                            String requete = "";
                            int premier = 1;

                            String st1 = tab_onglet3.tab_jtf_chambre.get(0).getText().trim();

                            int integer1 =0;
                            if(tab_onglet3.tab_jtf_chambre.get(1).getText().length() != 0){
                                integer1= Integer.parseInt(tab_onglet3.tab_jtf_chambre.get(1).getText().trim());
                            }
                            int integer2 =0;
                            if(tab_onglet3.tab_jtf_chambre.get(2).getText().length() != 0){
                                integer2= Integer.parseInt(tab_onglet3.tab_jtf_chambre.get(2).getText().trim());
                            }                        
                            int integer3 =0;
                            if(tab_onglet3.tab_jtf_chambre.get(3).getText().length() != 0){
                                integer3= Integer.parseInt(tab_onglet3.tab_jtf_chambre.get(3).getText().trim());
                            }
                            if(st1.compareTo("") == 0 && integer1== 0 && integer2== 0 && integer3== 0){
                                
                                    JOptionPane jop2 = new JOptionPane();
                                    jop2.showMessageDialog(null, "Attention", "Veuillez remplir les champs", JOptionPane.WARNING_MESSAGE);
                            }

                            else{
                                if (st1.compareTo("") != 0 ){
                                    requete +="\""+st1+"\"";
                                    premier = 0;
                                }
                                if (integer1 != 0 ){
                                    if (premier ==0){
                                        requete += ",";
                                    }

                                    requete +="\""+integer1+"\"";
                                    premier = 0;

                                }
                                if (integer2 != 0 ){
                                    if (premier ==0){
                                        requete += ",";
                                    }
                                    requete +="\""+integer2+"\"";
                                    premier = 0;

                                }
                                if (integer3 != 0 ){
                                    if (premier ==0){
                                        requete += ",";
                                    }
                                    requete +="\""+integer3+"\"";
                                    premier = 0;

                                }

                               controle.ajouter_requete_chambre("`chambre`",requete); 
                                JOptionPane jop2 = new JOptionPane();
                                jop2.showMessageDialog(null, "okay", "yoo", JOptionPane.WARNING_MESSAGE);
                            }  
                        }
            
                        if(tab_onglet3.getSelectedIndex() ==2){
                            String requete = "";
                            int premier = 1;

                            int integer =0;
                            if(tab_onglet3.tab_jtf_employe.get(0).getText().length() != 0){
                                integer= Integer.parseInt(tab_onglet3.tab_jtf_employe.get(0).getText().trim());
                            }
                            String st1= tab_onglet3.tab_jtf_employe.get(1).getText().trim();
                            String st2= tab_onglet3.tab_jtf_employe.get(2).getText().trim();
                            String st3= tab_onglet3.tab_jtf_employe.get(3).getText().trim();
                            String st4= tab_onglet3.tab_jtf_employe.get(4).getText().trim();

                            if(integer == 0 && st1.compareTo("") == 0 && st2.compareTo("") == 0 && st3.compareTo("") == 0 && st4.compareTo("")==0 ){
                              JOptionPane jop2 = new JOptionPane();
                              jop2.showMessageDialog(null, "Attention", "Veuillez remplir les champs", JOptionPane.WARNING_MESSAGE);
                            }
                            else {
                                if (integer != 0 ){
                                    requete +="\""+integer+"\"";
                                    premier = 0;
                                }
                                if (st1.compareTo("") != 0 ){
                                    if (premier ==0){
                                        requete += ",";
                                    }
                                    requete +="\""+st1+"\"";
                                    premier = 0;

                                }
                                if (st2.compareTo("") != 0 ){
                                    if (premier ==0){
                                        requete += ",";
                                    }
                                    requete +="\""+st2+"\"";
                                    premier = 0;

                                }
                                if (st3.compareTo("") != 0 ){
                                    if (premier ==0){
                                        requete += ",";
                                    }
                                    requete +="\""+st3+"\"";
                                    premier = 0;

                                }
                                if (st4.compareTo("") != 0 ){
                                    if (premier ==0){
                                        requete += ",";
                                    }
                                    requete +="\""+st4+"\"";
                                    premier = 0;

                                }
                               
                                    controle.ajouter_requete_employe("`employe`",requete); 
                             
                                    JOptionPane jop2 = new JOptionPane();
                                    jop2.showMessageDialog(null, "okay", "yoo", JOptionPane.WARNING_MESSAGE);

                                }

                            }
                        
                        
                        if(tab_onglet3.getSelectedIndex() ==3){
                            String requete = "";
                            int premier = 1;

                            int integer1 =0;
                            if(tab_onglet3.tab_jtf_docteur.get(0).getText().length() != 0){
                                integer1= Integer.parseInt(tab_onglet3.tab_jtf_docteur.get(0).getText().trim());
                            }
                            
                            String st1 = tab_onglet3.tab_jtf_docteur.get(1).getText().trim();
                          
                            if( integer1== 0 && st1.compareTo("") == 0 ){
                                JOptionPane jop2 = new JOptionPane();
                                jop2.showMessageDialog(null, "Attention", "Veuillez remplir les champs", JOptionPane.WARNING_MESSAGE);
                            }

                            else{
                                if (integer1 != 0 ){
                                    requete +="\""+integer1+"\"";
                                    premier = 0;
                                }
                                if (st1.compareTo("") != 0 ){
                                    if (premier ==0){
                                        requete += ",";
                                    }

                                    requete +="\""+st1+"\"";
                                    premier = 0;
                                }
                             
                                controle.ajouter_requete_docteur("`docteur`",requete); 
                                JOptionPane jop2 = new JOptionPane();
                                jop2.showMessageDialog(null, "okay", "yoo", JOptionPane.WARNING_MESSAGE);
                            }  
                        }
                        
                        
                        if(tab_onglet3.getSelectedIndex() ==4){
                            String requete = "";
                            int premier = 1;

                            int integer1 =0;
                            if(tab_onglet3.tab_jtf_infirmier.get(0).getText().length() != 0){
                                integer1= Integer.parseInt(tab_onglet3.tab_jtf_infirmier.get(0).getText().trim());
                            }
                            
                            
                            String st1 = tab_onglet3.tab_jtf_infirmier.get(1).getText().trim();
                            String st2 = tab_onglet3.tab_jtf_infirmier.get(2).getText().trim();
                          
                            int integer2 =0;
                            if(tab_onglet3.tab_jtf_infirmier.get(3).getText().length() != 0){
                                integer2= Integer.parseInt(tab_onglet3.tab_jtf_infirmier.get(3).getText().trim());
                            }
                            if( integer1== 0 && st1.compareTo("") == 0 && st2.compareTo("") == 0 && integer2 == 0 ){
                                JOptionPane jop2 = new JOptionPane();
                                jop2.showMessageDialog(null, "Attention", "Veuillez remplir les champs", JOptionPane.WARNING_MESSAGE);
                            }

                            else{
                                if (integer1 != 0 ){
                                    requete +="\""+integer1+"\"";
                                    premier = 0;
                                }
                                if (st1.compareTo("") != 0 ){
                                    if (premier ==0){
                                        requete += ",";
                                    }

                                    requete +="\""+st1+"\"";
                                    premier = 0;

                                }       
                                
                                if (st2.compareTo("") != 0 ){
                                    if (premier ==0){
                                        requete += ",";
                                    }

                                    requete +="\""+st2+"\"";
                                    premier = 0;

                                }       
                                if (integer2 != 0 ){
                                    if (premier ==0){
                                        requete += ",";
                                    }

                                    requete +="\""+integer2+"\"";
                                    premier = 0;

                                }
                             
                      
                                controle.ajouter_requete_infirmier("`infirmier`",requete); 
                                JOptionPane jop2 = new JOptionPane();
                                jop2.showMessageDialog(null, "okay", "yoo", JOptionPane.WARNING_MESSAGE);
                               
                            }  
                        }
                        
                        
                        if(tab_onglet3.getSelectedIndex() ==5){
                            String requete = "";
                            int premier = 1;

                            int integer1 =0;
                            if(tab_onglet3.tab_jtf_malade.get(0).getText().length() != 0){
                                integer1= Integer.parseInt(tab_onglet3.tab_jtf_malade.get(0).getText().trim());
                            }
                            
                            String st1 = tab_onglet3.tab_jtf_malade.get(1).getText().trim();
                            String st2 = tab_onglet3.tab_jtf_malade.get(2).getText().trim();
                            String st3 = tab_onglet3.tab_jtf_malade.get(3).getText().trim();
                            String st4 = tab_onglet3.tab_jtf_malade.get(4).getText().trim();
                            String st5 = tab_onglet3.tab_jtf_malade.get(5).getText().trim();
                          
                          
                            if( integer1== 0 && st1.compareTo("") == 0 && st2.compareTo("") == 0 && st3.compareTo("") == 0 && st4.compareTo("") ==0 && st5.compareTo("") ==0  ){
                                JOptionPane jop2 = new JOptionPane();
                                jop2.showMessageDialog(null, "Attention", "Veuillez remplir les champs", JOptionPane.WARNING_MESSAGE);
                            }

                            else{
                                if (integer1 != 0 ){
                                    requete +="\""+integer1+"\"";
                                    premier = 0;
                                }
                                if (st1.compareTo("") != 0 ){
                                    if (premier ==0){
                                        requete += ",";
                                    }

                                    requete +="\""+st1+"\"";
                                    premier = 0;

                                }       
                                
                                if (st2.compareTo("") != 0 ){
                                    if (premier ==0){
                                        requete += ",";
                                    }

                                    requete +="\""+st2+"\"";
                                    premier = 0;

                                }       
                                if (st3.compareTo("") != 0 ){
                                    if (premier ==0){
                                        requete += ",";
                                    }

                                    requete +="\""+st3+"\"";
                                    premier = 0;

                                }  
                                
                                if (st4.compareTo("") != 0 ){
                                    if (premier ==0){
                                        requete += ",";
                                    }

                                    requete +="\""+st4+"\"";
                                    premier = 0;

                                }
                                
                                if (st5.compareTo("") != 0 ){
                                    if (premier ==0){
                                        requete += ",";
                                    }

                                    requete +="\""+st5+"\"";
                                    premier = 0;

                                }
                         
                                controle.ajouter_requete_malade("`malade`",requete); 
                                JOptionPane jop2 = new JOptionPane();
                                jop2.showMessageDialog(null, "okay", "yoo", JOptionPane.WARNING_MESSAGE);
                            }  
                        }
                        
                        if(tab_onglet3.getSelectedIndex() ==6){
                            String requete = "";
                            int premier = 1;

                            int integer1 =0;
                            if(tab_onglet3.tab_jtf_hospital.get(0).getText().length() != 0){
                                integer1= Integer.parseInt(tab_onglet3.tab_jtf_hospital.get(0).getText().trim());
                            }
                            
                            String st1 = tab_onglet3.tab_jtf_hospital.get(1).getText().trim();
                           
                            int integer2 =0;
                            if(tab_onglet3.tab_jtf_hospital.get(2).getText().length() != 0){
                                integer2= Integer.parseInt(tab_onglet3.tab_jtf_hospital.get(2).getText().trim());
                            } 
                            
                            int integer3 =0;
                            if(tab_onglet3.tab_jtf_hospital.get(3).getText().length() != 0){
                                integer3= Integer.parseInt(tab_onglet3.tab_jtf_hospital.get(3).getText().trim());
                            }
                          
                        
                            if( integer1== 0 && st1.compareTo("") == 0 && integer2 == 0 && integer3 == 0){
                                
                                JOptionPane jop2 = new JOptionPane();
                                jop2.showMessageDialog(null, "Attention", "Veuillez remplir les champs", JOptionPane.WARNING_MESSAGE);
                            }

                            else{
                                if (integer1 != 0 ){
                                    requete +="\""+integer1+"\"";
                                    premier = 0;
                                }
                                if (st1.compareTo("") != 0 ){
                                    if (premier ==0){
                                        requete += ",";
                                    }

                                    requete +="\""+st1+"\"";
                                    premier = 0;

                                }       
                                
                                if (integer2 != 0 ){
                                    if (premier ==0){
                                        requete += ",";
                                    }

                                    requete +="\""+integer2+"\"";
                                    premier = 0;

                                }       
                                if (integer3 != 0 ){
                                    if (premier ==0){
                                        requete += ",";
                                    }

                                    requete +="\""+integer3+"\"";
                                    premier = 0;

                                }  
                                
                            
                                controle.ajouter_requete_hopital("`hospitalisation`",requete); 
                                JOptionPane jop2 = new JOptionPane();
                                jop2.showMessageDialog(null, "okay", "yoo", JOptionPane.WARNING_MESSAGE);
                            }  
                        }
                         
                        if(tab_onglet3.getSelectedIndex() ==7){
                           
      
                            String requete = "";
                            int premier = 1;

                            int integer1 =0;
                            if(tab_onglet3.tab_jtf_soin.get(0).getText().length() != 0){
                                integer1= Integer.parseInt(tab_onglet3.tab_jtf_soin.get(0).getText().trim());
                            }
                            
                            int integer2 =0;
                            if(tab_onglet3.tab_jtf_soin.get(1).getText().length() != 0){
                                integer2= Integer.parseInt(tab_onglet3.tab_jtf_soin.get(1).getText().trim());
                            } 
                            
                            if( integer1== 0 && integer2 == 0 ){
                                 
                                JOptionPane jop2 = new JOptionPane();
                                jop2.showMessageDialog(null, "Attention", "Veuillez remplir les champs", JOptionPane.WARNING_MESSAGE);
                            }

                            else{
                                if (integer1 != 0 ){
                                    requete +="\""+integer1+"\"";
                                    premier = 0;
                                }
                    
                                if (integer2 != 0 ){
                                    if (premier ==0){
                                        requete += ",";
                                    }

                                    requete +="\""+integer2+"\"";
                                    premier = 0;

                                }       
               
                               controle.ajouter_requete_soigne("`soigne`",requete); 
                               JOptionPane jop2 = new JOptionPane();
                               jop2.showMessageDialog(null, "okay", "yoo", JOptionPane.WARNING_MESSAGE);
                            }  
                        }  
                }
                
                if (e.getSource()==supprimer_bouton){
                    
                    if(tab_onglet3.getSelectedIndex() ==0){
                        
                        String requete = "";
                        int premier = 1;

                        String st1 = tab_onglet3.tab_jtf_service.get(0).getText().trim();
                        String st2= tab_onglet3.tab_jtf_service.get(1).getText().trim();
                        String st3= tab_onglet3.tab_jtf_service.get(2).getText().trim();
                        int integer =0;
                        if(tab_onglet3.tab_jtf_service.get(3).getText().length() != 0){
                            integer= Integer.parseInt(tab_onglet3.tab_jtf_service.get(3).getText().trim());
                        }
                        if(st1.compareTo("") == 0 && st2.compareTo("") == 0 && st3.compareTo("") == 0 && integer== 0){
                           
                            JOptionPane jop2 = new JOptionPane();
                            jop2.showMessageDialog(null, "Attention", "Veuillez remplir les champs", JOptionPane.WARNING_MESSAGE);
                            }
                            else {
                                
                                controle.supprimer(controle.write_requete_delete_service(st1));
                                JOptionPane jop2 = new JOptionPane();
                                 jop2.showMessageDialog(null, "okay", "yoo", JOptionPane.WARNING_MESSAGE);
                   
                            }
                           
                        }
                    
                        if(tab_onglet3.getSelectedIndex() ==1){
                            String requete = "";
                            int premier = 1;

                            String st1 = tab_onglet3.tab_jtf_chambre.get(0).getText().trim();

                            int integer1 =0;
                            if(tab_onglet3.tab_jtf_chambre.get(1).getText().length() != 0){
                                integer1= Integer.parseInt(tab_onglet3.tab_jtf_chambre.get(1).getText().trim());
                            }
                            int integer2 =0;
                            if(tab_onglet3.tab_jtf_chambre.get(2).getText().length() != 0){
                                integer2= Integer.parseInt(tab_onglet3.tab_jtf_chambre.get(2).getText().trim());
                            }                        
                            int integer3 =0;
                            if(tab_onglet3.tab_jtf_chambre.get(3).getText().length() != 0){
                                integer3= Integer.parseInt(tab_onglet3.tab_jtf_chambre.get(3).getText().trim());
                            }
                            if(st1.compareTo("") == 0 && integer1== 0 && integer2== 0 && integer3== 0){
                                
                                    JOptionPane jop2 = new JOptionPane();
                                    jop2.showMessageDialog(null, "Attention", "Veuillez remplir les champs", JOptionPane.WARNING_MESSAGE);
                            }

                            else{
                      
                               controle.supprimer(controle.write_requete_delete_chambre(integer1));
                               
                                JOptionPane jop2 = new JOptionPane();
                                jop2.showMessageDialog(null, "okay", "yoo", JOptionPane.WARNING_MESSAGE);}
                            }
                        
                        if(tab_onglet3.getSelectedIndex() ==2){
                            String requete = "";
                            int premier = 1;

                            int integer =0;
                            if(tab_onglet3.tab_jtf_employe.get(0).getText().length() != 0){
                                integer= Integer.parseInt(tab_onglet3.tab_jtf_employe.get(0).getText().trim());
                            }
                            String st1= tab_onglet3.tab_jtf_employe.get(1).getText().trim();
                            String st2= tab_onglet3.tab_jtf_employe.get(2).getText().trim();
                            String st3= tab_onglet3.tab_jtf_employe.get(3).getText().trim();
                            String st4= tab_onglet3.tab_jtf_employe.get(4).getText().trim();

                            if(integer == 0 && st1.compareTo("") == 0 && st2.compareTo("") == 0 && st3.compareTo("") == 0 && st4.compareTo("")==0 ){
                              JOptionPane jop2 = new JOptionPane();
                              jop2.showMessageDialog(null, "Attention", "Veuillez remplir les champs", JOptionPane.WARNING_MESSAGE);
                            }
                            else{
                            controle.supprimer(controle.write_requete_delete_employe(integer));
                            
                            JOptionPane jop3 = new JOptionPane();
                            jop3.showMessageDialog(null, "okkk", "OK", JOptionPane.WARNING_MESSAGE);}
                        
                }
                        
                         if(tab_onglet3.getSelectedIndex() ==3){
                            String requete = "";
                            int premier = 1;

                            int integer1 =0;
                            if(tab_onglet3.tab_jtf_docteur.get(0).getText().length() != 0){
                                integer1= Integer.parseInt(tab_onglet3.tab_jtf_docteur.get(0).getText().trim());
                            }
                            
                            String st1 = tab_onglet3.tab_jtf_docteur.get(1).getText().trim();
                          
                            if( integer1== 0 && st1.compareTo("") == 0 ){
                                JOptionPane jop2 = new JOptionPane();
                                jop2.showMessageDialog(null, "Attention", "Veuillez remplir les champs", JOptionPane.WARNING_MESSAGE);
                            }

                            else{
                               
                             
                                controle.supprimer(controle.write_requete_delete_docteur(integer1)); 
                                JOptionPane jop2 = new JOptionPane();
                                jop2.showMessageDialog(null, "okay", "yoo", JOptionPane.WARNING_MESSAGE);
                            }  
                        }
                        
                        
                        if(tab_onglet3.getSelectedIndex() ==4){
                            String requete = "";
                            int premier = 1;

                            int integer1 =0;
                            if(tab_onglet3.tab_jtf_infirmier.get(0).getText().length() != 0){
                                integer1= Integer.parseInt(tab_onglet3.tab_jtf_infirmier.get(0).getText().trim());
                            }
                            
                            
                            String st1 = tab_onglet3.tab_jtf_infirmier.get(1).getText().trim();
                            String st2 = tab_onglet3.tab_jtf_infirmier.get(2).getText().trim();
                          
                            int integer2 =0;
                            if(tab_onglet3.tab_jtf_infirmier.get(3).getText().length() != 0){
                                integer2= Integer.parseInt(tab_onglet3.tab_jtf_infirmier.get(3).getText().trim());
                            }
                            if( integer1== 0 && st1.compareTo("") == 0 && st2.compareTo("") == 0 && integer2 == 0 ){
                                JOptionPane jop2 = new JOptionPane();
                                jop2.showMessageDialog(null, "Attention", "Veuillez remplir les champs", JOptionPane.WARNING_MESSAGE);
                            }

                            else{
                              
                                controle.supprimer(controle.write_requete_delete_infirmier(integer1));
                                JOptionPane jop2 = new JOptionPane();
                                jop2.showMessageDialog(null, "okay", "yoo", JOptionPane.WARNING_MESSAGE);
                               
                            }  
                        }
                        
                        
                        if(tab_onglet3.getSelectedIndex() ==5){
                            String requete = "";
                            int premier = 1;

                            int integer1 =0;
                            if(tab_onglet3.tab_jtf_malade.get(0).getText().length() != 0){
                                integer1= Integer.parseInt(tab_onglet3.tab_jtf_malade.get(0).getText().trim());
                            }
                            
                            String st1 = tab_onglet3.tab_jtf_malade.get(1).getText().trim();
                            String st2 = tab_onglet3.tab_jtf_malade.get(2).getText().trim();
                            String st3 = tab_onglet3.tab_jtf_malade.get(3).getText().trim();
                            String st4 = tab_onglet3.tab_jtf_malade.get(4).getText().trim();
                            String st5 = tab_onglet3.tab_jtf_malade.get(5).getText().trim();
                          
                          
                            if( integer1== 0 && st1.compareTo("") == 0 && st2.compareTo("") == 0 && st3.compareTo("") == 0 && st4.compareTo("") ==0 && st5.compareTo("") ==0  ){
                                JOptionPane jop2 = new JOptionPane();
                                jop2.showMessageDialog(null, "Attention", "Veuillez remplir les champs", JOptionPane.WARNING_MESSAGE);
                            }

                            else{
                            
                                controle.supprimer(controle.write_requete_delete_malade(integer1));
                                JOptionPane jop2 = new JOptionPane();
                                jop2.showMessageDialog(null, "okay", "yoo", JOptionPane.WARNING_MESSAGE);
                            }  
                        }
                        
                        if(tab_onglet3.getSelectedIndex() ==6){
                            String requete = "";
                            int premier = 1;

                            int integer1 =0;
                            if(tab_onglet3.tab_jtf_hospital.get(0).getText().length() != 0){
                                integer1= Integer.parseInt(tab_onglet3.tab_jtf_hospital.get(0).getText().trim());
                            }
                            
                            String st1 = tab_onglet3.tab_jtf_hospital.get(1).getText().trim();
                           
                            int integer2 =0;
                            if(tab_onglet3.tab_jtf_hospital.get(2).getText().length() != 0){
                                integer2= Integer.parseInt(tab_onglet3.tab_jtf_hospital.get(2).getText().trim());
                            } 
                            
                            int integer3 =0;
                            if(tab_onglet3.tab_jtf_hospital.get(3).getText().length() != 0){
                                integer3= Integer.parseInt(tab_onglet3.tab_jtf_hospital.get(3).getText().trim());
                            }
                          
                        
                            if( integer1== 0 && st1.compareTo("") == 0 && integer2 == 0 && integer3 == 0){
                                
                                JOptionPane jop2 = new JOptionPane();
                                jop2.showMessageDialog(null, "Attention", "Veuillez remplir les champs", JOptionPane.WARNING_MESSAGE);
                            }

                            else{
                            
                                controle.supprimer(controle.write_requete_delete_hopital(integer1));
                                JOptionPane jop2 = new JOptionPane();
                                jop2.showMessageDialog(null, "okay", "yoo", JOptionPane.WARNING_MESSAGE);
                            }  
                        }
                         
                        if(tab_onglet3.getSelectedIndex() ==7){
                           
      
                            String requete = "";
                            int premier = 1;

                            int integer1 =0;
                            if(tab_onglet3.tab_jtf_soin.get(0).getText().length() != 0){
                                integer1= Integer.parseInt(tab_onglet3.tab_jtf_soin.get(0).getText().trim());
                            }
                            
                            int integer2 =0;
                            if(tab_onglet3.tab_jtf_soin.get(1).getText().length() != 0){
                                integer2= Integer.parseInt(tab_onglet3.tab_jtf_soin.get(1).getText().trim());
                            } 
                            
                            if( integer1== 0 && integer2 == 0 ){
                                 
                                JOptionPane jop2 = new JOptionPane();
                                jop2.showMessageDialog(null, "Attention", "Veuillez remplir les champs", JOptionPane.WARNING_MESSAGE);
                            }

                            else{
                               
                                ///relier la table soigne /malade.. 
                                
                                
                                
                              // controle.ajouter_requete_soigne("`soigne`",requete); 
                               JOptionPane jop2 = new JOptionPane();
                               jop2.showMessageDialog(null, "okay", "yoo", JOptionPane.WARNING_MESSAGE);
                            }  
                        }  
             
                    }
      
                if (e.getSource()== modifier_bouton){
                    if(tab_onglet3.getSelectedIndex() ==0){
                        
                        String requete = "";
                        int premier = 1;

                        String st1 = tab_onglet3.tab_jtf_service.get(0).getText().trim();
                        String st2= tab_onglet3.tab_jtf_service.get(1).getText().trim();
                        String st3= tab_onglet3.tab_jtf_service.get(2).getText().trim();
                        int integer =0;
                        if(tab_onglet3.tab_jtf_service.get(3).getText().length() != 0){
                            integer= Integer.parseInt(tab_onglet3.tab_jtf_service.get(3).getText().trim());
                        }
                        if(st1.compareTo("") == 0 && st2.compareTo("") == 0 && st3.compareTo("") == 0 && integer== 0){
                           
                            JOptionPane jop2 = new JOptionPane();
                            jop2.showMessageDialog(null, "Attention", "Veuillez remplir les champs", JOptionPane.WARNING_MESSAGE);
                            }
                            else {
                                
                                controle.modifier(controle.write_requete_update_service(st1,st2,st3,integer));
                                JOptionPane jop2 = new JOptionPane();
                                 jop2.showMessageDialog(null, "okay", "yoo", JOptionPane.WARNING_MESSAGE);
                   
                            }
                           
                        }
                    
                        if(tab_onglet3.getSelectedIndex() ==1){
                            String requete = "";
                            int premier = 1;

                            String st1 = tab_onglet3.tab_jtf_chambre.get(0).getText().trim();

                            int integer1 =0;
                            if(tab_onglet3.tab_jtf_chambre.get(1).getText().length() != 0){
                                integer1= Integer.parseInt(tab_onglet3.tab_jtf_chambre.get(1).getText().trim());
                            }
                            int integer2 =0;
                            if(tab_onglet3.tab_jtf_chambre.get(2).getText().length() != 0){
                                integer2= Integer.parseInt(tab_onglet3.tab_jtf_chambre.get(2).getText().trim());
                            }                        
                            int integer3 =0;
                            if(tab_onglet3.tab_jtf_chambre.get(3).getText().length() != 0){
                                integer3= Integer.parseInt(tab_onglet3.tab_jtf_chambre.get(3).getText().trim());
                            }
                            if(st1.compareTo("") == 0 && integer1== 0 && integer2== 0 && integer3== 0){
                                
                                    JOptionPane jop2 = new JOptionPane();
                                    jop2.showMessageDialog(null, "Attention", "Veuillez remplir les champs", JOptionPane.WARNING_MESSAGE);
                            }

                            else{
                      
                               controle.modifier(controle.write_requete_update_chambre(st1, integer1, integer2, integer3));
                               
                                JOptionPane jop2 = new JOptionPane();
                                jop2.showMessageDialog(null, "okay", "yoo", JOptionPane.WARNING_MESSAGE);}
                            }
                        
                        if(tab_onglet3.getSelectedIndex() ==2){
                            String requete = "";
                            int premier = 1;

                            int integer =0;
                            if(tab_onglet3.tab_jtf_employe.get(0).getText().length() != 0){
                                integer= Integer.parseInt(tab_onglet3.tab_jtf_employe.get(0).getText().trim());
                            }
                            String st1= tab_onglet3.tab_jtf_employe.get(1).getText().trim();
                            String st2= tab_onglet3.tab_jtf_employe.get(2).getText().trim();
                            String st3= tab_onglet3.tab_jtf_employe.get(3).getText().trim();
                            String st4= tab_onglet3.tab_jtf_employe.get(4).getText().trim();

                            if(integer == 0 && st1.compareTo("") == 0 && st2.compareTo("") == 0 && st3.compareTo("") == 0 && st4.compareTo("")==0 ){
                              JOptionPane jop2 = new JOptionPane();
                              jop2.showMessageDialog(null, "Attention", "Veuillez remplir les champs", JOptionPane.WARNING_MESSAGE);
                            }
                            else{
                            controle.modifier(controle.write_requete_update_employe(integer, st1, st2, st3, st4));
                            
                            JOptionPane jop3 = new JOptionPane();
                            jop3.showMessageDialog(null, "okkk", "OK", JOptionPane.WARNING_MESSAGE);}
                        
                }
                        
                         if(tab_onglet3.getSelectedIndex() ==3){
                            String requete = "";
                            int premier = 1;

                            int integer1 =0;
                            if(tab_onglet3.tab_jtf_docteur.get(0).getText().length() != 0){
                                integer1= Integer.parseInt(tab_onglet3.tab_jtf_docteur.get(0).getText().trim());
                            }
                            
                            String st1 = tab_onglet3.tab_jtf_docteur.get(1).getText().trim();
                          
                            if( integer1== 0 && st1.compareTo("") == 0 ){
                                JOptionPane jop2 = new JOptionPane();
                                jop2.showMessageDialog(null, "Attention", "Veuillez remplir les champs", JOptionPane.WARNING_MESSAGE);
                            }

                            else{
                               
                             
                                controle.modifier(controle.write_requete_update_docteur(integer1, st1));
                                JOptionPane jop2 = new JOptionPane();
                                jop2.showMessageDialog(null, "okay", "yoo", JOptionPane.WARNING_MESSAGE);
                            }  
                        }
                        
                        
                        if(tab_onglet3.getSelectedIndex() ==4){
                            String requete = "";
                            int premier = 1;

                            int integer1 =0;
                            if(tab_onglet3.tab_jtf_infirmier.get(0).getText().length() != 0){
                                integer1= Integer.parseInt(tab_onglet3.tab_jtf_infirmier.get(0).getText().trim());
                            }
                            
                            
                            String st1 = tab_onglet3.tab_jtf_infirmier.get(1).getText().trim();
                            String st2 = tab_onglet3.tab_jtf_infirmier.get(2).getText().trim();
                          
                            int integer2 =0;
                            if(tab_onglet3.tab_jtf_infirmier.get(3).getText().length() != 0){
                                integer2= Integer.parseInt(tab_onglet3.tab_jtf_infirmier.get(3).getText().trim());
                            }
                            if( integer1== 0 && st1.compareTo("") == 0 && st2.compareTo("") == 0 && integer2 == 0 ){
                                JOptionPane jop2 = new JOptionPane();
                                jop2.showMessageDialog(null, "Attention", "Veuillez remplir les champs", JOptionPane.WARNING_MESSAGE);
                            }

                            else{
                              
                                controle.modifier(controle.write_requete_update_infirmier(integer1, st1, st2, integer2));
                                JOptionPane jop2 = new JOptionPane();
                                jop2.showMessageDialog(null, "okay", "yoo", JOptionPane.WARNING_MESSAGE);
                               
                            }  
                        }
                        
                        
                        if(tab_onglet3.getSelectedIndex() ==5){
                            String requete = "";
                            int premier = 1;

                            int integer1 =0;
                            if(tab_onglet3.tab_jtf_malade.get(0).getText().length() != 0){
                                integer1= Integer.parseInt(tab_onglet3.tab_jtf_malade.get(0).getText().trim());
                            }
                            
                            String st1 = tab_onglet3.tab_jtf_malade.get(1).getText().trim();
                            String st2 = tab_onglet3.tab_jtf_malade.get(2).getText().trim();
                            String st3 = tab_onglet3.tab_jtf_malade.get(3).getText().trim();
                            String st4 = tab_onglet3.tab_jtf_malade.get(4).getText().trim();
                            String st5 = tab_onglet3.tab_jtf_malade.get(5).getText().trim();
                          
                          
                            if( integer1== 0 && st1.compareTo("") == 0 && st2.compareTo("") == 0 && st3.compareTo("") == 0 && st4.compareTo("") ==0 && st5.compareTo("") ==0  ){
                                JOptionPane jop2 = new JOptionPane();
                                jop2.showMessageDialog(null, "Attention", "Veuillez remplir les champs", JOptionPane.WARNING_MESSAGE);
                            }

                            else{
                            
                                controle.modifier(controle.write_requete_update_malade(integer1, st1, st2, st3, st4, st5));
                                JOptionPane jop2 = new JOptionPane();
                                jop2.showMessageDialog(null, "okay", "yoo", JOptionPane.WARNING_MESSAGE);
                            }  
                        }
                        
                        if(tab_onglet3.getSelectedIndex() ==6){
                            String requete = "";
                            int premier = 1;

                            int integer1 =0;
                            if(tab_onglet3.tab_jtf_hospital.get(0).getText().length() != 0){
                                integer1= Integer.parseInt(tab_onglet3.tab_jtf_hospital.get(0).getText().trim());
                            }
                            
                            String st1 = tab_onglet3.tab_jtf_hospital.get(1).getText().trim();
                           
                            int integer2 =0;
                            if(tab_onglet3.tab_jtf_hospital.get(2).getText().length() != 0){
                                integer2= Integer.parseInt(tab_onglet3.tab_jtf_hospital.get(2).getText().trim());
                            } 
                            
                            int integer3 =0;
                            if(tab_onglet3.tab_jtf_hospital.get(3).getText().length() != 0){
                                integer3= Integer.parseInt(tab_onglet3.tab_jtf_hospital.get(3).getText().trim());
                            }
                          
                        
                            if( integer1== 0 && st1.compareTo("") == 0 && integer2 == 0 && integer3 == 0){
                                
                                JOptionPane jop2 = new JOptionPane();
                                jop2.showMessageDialog(null, "Attention", "Veuillez remplir les champs", JOptionPane.WARNING_MESSAGE);
                            }

                            else{
                            
                                controle.modifier(controle.write_requete_update_hopital(integer1, st1, integer2, integer3));
                                JOptionPane jop2 = new JOptionPane();
                                jop2.showMessageDialog(null, "okay", "yoo", JOptionPane.WARNING_MESSAGE);
                            }  
                        }
                         
                        if(tab_onglet3.getSelectedIndex() ==7){
                           
      
                            String requete = "";
                            int premier = 1;

                            int integer1 =0;
                            if(tab_onglet3.tab_jtf_soin.get(0).getText().length() != 0){
                                integer1= Integer.parseInt(tab_onglet3.tab_jtf_soin.get(0).getText().trim());
                            }
                            
                            int integer2 =0;
                            if(tab_onglet3.tab_jtf_soin.get(1).getText().length() != 0){
                                integer2= Integer.parseInt(tab_onglet3.tab_jtf_soin.get(1).getText().trim());
                            } 
                            
                            if( integer1== 0 && integer2 == 0 ){
                                 
                                JOptionPane jop2 = new JOptionPane();
                                jop2.showMessageDialog(null, "Attention", "Veuillez remplir les champs", JOptionPane.WARNING_MESSAGE);
                            }

                            else{
                            
                                controle.modifier(controle.write_requete_update_soin(integer1, integer2));
                                JOptionPane jop2 = new JOptionPane();
                                jop2.showMessageDialog(null, "okay", "yoo", JOptionPane.WARNING_MESSAGE);
                            }  
                        }
                
                
                        

                    
                
                        }
                                if (e.getSource()== maj){
                                    affiche_chart();
                                }

            this.repaint();
            } else {
                            JOptionPane jop2 = new JOptionPane();
                            jop2.showMessageDialog(null, "Message préventif", "Attention, non connecte", JOptionPane.WARNING_MESSAGE);
                        
                        }
        
        }
        
                        
                        
                        
                    
                
                    
		
		
		
		
	
	
        
        public void affiche_result(char ch[]){
            
            String str_temp = "";
            for(char c:ch){
            if(c != '\n'){
                if(c != ','){
                    str_temp += c;
                }
                else {
                   result.add(new JLabel(str_temp));
                   str_temp = "";
                }
            }
            else{
                result.add(new JLabel(str_temp));            
                str_temp = "";

            }
        }    
            
        
}
        public void affiche_chart(){
            
            pan3.add(new ChartPanel(data()));
            pan3.repaint();
                  
        }
        
        public JFreeChart data(){
                  DefaultPieDataset dataset = new DefaultPieDataset( );
                  ArrayList<Integer> nombre = new ArrayList<>();
                  nombre =controle.histograme1();
                  System.out.println(nombre.get(0));
                  System.out.println(nombre.get(1));
                  System.out.println(nombre.get(2));
                  dataset.setValue("Infirmier",nombre.get(0));
                  dataset.setValue("Docteur",nombre.get(1));
                  dataset.setValue("Autre",nombre.get(2) - (nombre.get(1) +nombre.get(0)) );

                  JFreeChart chart = ChartFactory.createPieChart("Emplye",dataset,true,true,false);
                  return chart;
        }
}

	
	

